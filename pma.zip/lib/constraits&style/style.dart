import 'package:flutter/cupertino.dart';

TextStyle txtStyle = const TextStyle(
  color: Color(0xff787468),
);

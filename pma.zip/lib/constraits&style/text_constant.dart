class TextConstant {
  static const Map en = {
    "DetailScreen": {
      "Task": "Task",
      "AddTask": "Add Task",
    },
  };
}
